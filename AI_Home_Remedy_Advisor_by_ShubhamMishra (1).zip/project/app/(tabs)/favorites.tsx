import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { Heart, Share, BookmarkPlus } from 'lucide-react-native';

export default function FavoritesScreen() {
  const [favoriteRemedies] = useState([
    {
      id: 1,
      name: 'Ginger Tea for Nausea',
      category: 'Digestive',
      ingredients: ['Fresh ginger', 'Hot water', 'Honey'],
      method: 'Steep fresh ginger slices in hot water for 10 minutes. Add honey to taste.',
      dateAdded: '2024-01-15',
    },
    {
      id: 2,
      name: 'Turmeric Milk for Better Sleep',
      category: 'General',
      ingredients: ['Turmeric powder', 'Warm milk', 'Black pepper', 'Honey'],
      method: 'Mix 1/2 tsp turmeric and a pinch of black pepper in warm milk. Sweeten with honey.',
      dateAdded: '2024-01-10',
    },
  ]);

  const renderFavoriteCard = (remedy: any) => (
    <View key={remedy.id} style={styles.favoriteCard}>
      <View style={styles.cardHeader}>
        <View style={styles.titleContainer}>
          <Text style={styles.remedyName}>{remedy.name}</Text>
          <View style={styles.categoryBadge}>
            <Text style={styles.categoryText}>{remedy.category}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.actionButton}>
          <Heart size={20} color="#EF4444" fill="#EF4444" />
        </TouchableOpacity>
      </View>

      <View style={styles.ingredientsContainer}>
        <Text style={styles.sectionTitle}>Ingredients:</Text>
        <Text style={styles.ingredientsText}>{remedy.ingredients.join(', ')}</Text>
      </View>

      <View style={styles.methodContainer}>
        <Text style={styles.sectionTitle}>Method:</Text>
        <Text style={styles.methodText}>{remedy.method}</Text>
      </View>

      <View style={styles.cardFooter}>
        <Text style={styles.dateText}>Added {new Date(remedy.dateAdded).toLocaleDateString()}</Text>
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButton}>
            <Share size={18} color="#6B7280" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <BookmarkPlus size={18} color="#6B7280" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Favorites</Text>
        <Text style={styles.headerSubtitle}>Saved remedies and treatments</Text>
      </View>

      {favoriteRemedies.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Heart size={48} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>No Favorites Yet</Text>
          <Text style={styles.emptyText}>
            Start exploring remedies and save your favorites here
          </Text>
          <TouchableOpacity style={styles.exploreButton}>
            <Text style={styles.exploreButtonText}>Explore Remedies</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView style={styles.favoritesContainer} showsVerticalScrollIndicator={false}>
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{favoriteRemedies.length}</Text>
              <Text style={styles.statLabel}>Saved Remedies</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>3</Text>
              <Text style={styles.statLabel}>Categories</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>5</Text>
              <Text style={styles.statLabel}>Times Used</Text>
            </View>
          </View>

          {favoriteRemedies.map(renderFavoriteCard)}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#374151',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  exploreButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  exploreButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  favoritesContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    paddingVertical: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: '700',
    color: '#10B981',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    textAlign: 'center',
  },
  favoriteCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  titleContainer: {
    flex: 1,
  },
  remedyName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 6,
  },
  categoryBadge: {
    backgroundColor: '#DBEAFE',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  categoryText: {
    fontSize: 12,
    color: '#1E40AF',
    fontWeight: '500',
  },
  actionButton: {
    padding: 8,
  },
  ingredientsContainer: {
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 6,
  },
  ingredientsText: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
  },
  methodContainer: {
    marginBottom: 16,
  },
  methodText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  dateText: {
    fontSize: 12,
    color: '#9CA3AF',
    fontWeight: '500',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
});