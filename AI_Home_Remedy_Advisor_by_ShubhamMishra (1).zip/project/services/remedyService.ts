import { remediesDatabase, symptomKeywords } from '@/data/remediesDatabase';

interface RemedyResponse {
  message: string;
  remedies: any[];
  confidence: 'high' | 'medium' | 'low';
}

// Simple keyword matching for symptom detection
function extractSymptoms(query: string): string[] {
  const lowerQuery = query.toLowerCase();
  const foundSymptoms: string[] = [];
  
  symptomKeywords.forEach(symptom => {
    if (lowerQuery.includes(symptom)) {
      foundSymptoms.push(symptom);
    }
  });
  
  return foundSymptoms;
}

// Find remedies based on detected symptoms
function findRelevantRemedies(symptoms: string[]): any[] {
  if (symptoms.length === 0) return [];
  
  const matchingRemedies = remediesDatabase.filter(remedy => 
    remedy.symptoms.some(symptom => 
      symptoms.some(userSymptom => 
        symptom.toLowerCase().includes(userSymptom) || 
        userSymptom.includes(symptom.toLowerCase())
      )
    )
  );
  
  // Sort by relevance (number of matching symptoms)
  return matchingRemedies.sort((a, b) => {
    const aMatches = a.symptoms.filter(symptom => 
      symptoms.some(userSymptom => 
        symptom.toLowerCase().includes(userSymptom) || 
        userSymptom.includes(symptom.toLowerCase())
      )
    ).length;
    
    const bMatches = b.symptoms.filter(symptom => 
      symptoms.some(userSymptom => 
        symptom.toLowerCase().includes(userSymptom) || 
        userSymptom.includes(symptom.toLowerCase())
      )
    ).length;
    
    return bMatches - aMatches;
  });
}

// Generate response based on query
export async function getRemedyAdvice(query: string): Promise<RemedyResponse> {
  const symptoms = extractSymptoms(query);
  const relevantRemedies = findRelevantRemedies(symptoms);
  
  if (symptoms.length === 0) {
    return {
      message: "I didn't detect any specific symptoms in your message. Could you please describe what you're experiencing? For example, you can say 'I have a headache' or 'I'm feeling nauseous'.",
      remedies: [],
      confidence: 'low'
    };
  }
  
  if (relevantRemedies.length === 0) {
    return {
      message: `I understand you're experiencing ${symptoms.join(', ')}. While I don't have specific remedies for these symptoms in my current database, I recommend consulting with a healthcare professional for proper guidance. In the meantime, ensure you stay hydrated and get adequate rest.`,
      remedies: [],
      confidence: 'low'
    };
  }
  
  const topRemedies = relevantRemedies.slice(0, 3);
  const symptomsText = symptoms.length === 1 ? symptoms[0] : symptoms.join(' and ');
  
  let message = `Based on your symptoms (${symptomsText}), here are some natural Ayurvedic remedies that might help:\n\n`;
  
  topRemedies.forEach((remedy, index) => {
    message += `${index + 1}. **${remedy.name}**: ${remedy.description}\n\n`;
  });
  
  message += `⚠️ **Important**: These are traditional remedies for general wellness. If symptoms persist for more than 2-3 days, worsen, or if you have underlying health conditions, please consult a healthcare professional immediately.`;
  
  return {
    message,
    remedies: topRemedies,
    confidence: relevantRemedies.length >= 2 ? 'high' : 'medium'
  };
}

// Generate daily wellness tips
export function getDailyTip(): string {
  const tips = [
    "Start your day with warm lemon water to boost digestion and detoxify your body.",
    "Practice deep breathing for 5 minutes daily to reduce stress and improve oxygen flow.",
    "Include turmeric in your meals for its powerful anti-inflammatory properties.",
    "Drink tulsi tea in the evening to support your immune system and promote relaxation.",
    "Massage your feet with warm sesame oil before bed for better sleep quality.",
    "Eat your largest meal at lunch when your digestive fire (Agni) is strongest.",
    "Keep your body hydrated by drinking room temperature water throughout the day.",
    "Practice oil pulling with coconut oil for 10 minutes to improve oral health.",
  ];
  
  const today = new Date().getDate();
  return tips[today % tips.length];
}